'use client'

import { ArrowDownRight, ArrowUpRight, BriefcaseBusiness, HeartPulse, Landmark, Map, Network, ShieldCheck, Sparkles, UserRound, WalletCards } from 'lucide-react'

const services = [
  { name: 'KKU-ID', description: 'A recognized identity for every wing.', icon: UserRound },
  { name: 'KKU-MAP', description: 'Navigate the night with confidence.', icon: Map },
  { name: 'KKU-JOBS', description: 'Find meaningful work in the ecosystem.', icon: BriefcaseBusiness },
  { name: 'KKU-BANK', description: 'Store, send, and grow your nectar.', icon: WalletCards },
  { name: 'KKU-CARE', description: 'Collective care for every community.', icon: HeartPulse },
  { name: 'KKU-PENSION', description: 'A softer landing for later seasons.', icon: ShieldCheck },
  { name: 'KKU-SOCIAL', description: 'Stay close to the people who matter.', icon: Network },
  { name: 'KKU-LIFE', description: 'One place for everything that comes next.', icon: Sparkles },
]

export default function KkuLanding() {
  return (
    <main className="kku-site">
      <nav className="kku-nav" aria-label="Primary navigation">
        <a href="#top" className="kku-mark" aria-label="KKU home"><span>KKU</span><small>Kothuk Kudumba Unit</small></a>
        <div className="kku-nav-links"><a href="#ecosystem">The ecosystem</a><a href="#concept">Our concept</a><a href="#join">Join KKU</a></div>
        <a href="#join" className="kku-nav-cta">Enter KKU <ArrowUpRight size={14} /></a>
      </nav>

      <section className="kku-hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-dot" /> System 01 / Est. tonight</p>
          <h1>The digital home<br /><em>for every mosquito.</em></h1>
          <p className="hero-lede">A connected ecosystem for the world&apos;s most misunderstood community. Identity, care, work, and a place to belong.</p>
          <div className="hero-actions"><a href="#join" className="kku-button">Enter KKU <ArrowUpRight size={16} /></a><a href="#ecosystem" className="text-link">Explore the system <ArrowDownRight size={16} /></a></div>
        </div>
        <div className="hero-art"><div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" /><img src="/kku-mosquito.png" alt="A mosquito suspended in the KKU system" /><p className="art-caption">A new kind of<br />social infrastructure</p><span className="art-coordinate">10° 19&apos; 48.2&quot; N / 76° 16&apos; 48.1&quot; E</span></div>
        <div className="hero-bottom"><span>Scroll to explore</span><span className="line" /><span>01 — 06</span></div>
      </section>

      <section className="intro-section reveal" id="concept"><p className="section-kicker">What is KKU?</p><div><h2>Not a network.<br /><span>A <em>neighborhood.</em></span></h2><p className="intro-body">KKU is a digital civilization built around the extraordinary lives of mosquitoes. A single, quiet system designed to make every night feel a little more possible.</p></div></section>

      <section className="ecosystem-section" id="ecosystem"><div className="section-heading reveal"><p className="section-kicker">The KKU ecosystem</p><h2>Everything you need.<br /><em>Nothing you don&apos;t.</em></h2><p>Eight essential systems. One shared pulse.</p></div><div className="service-grid">{services.map((service, index) => { const Icon = service.icon; return <a className="service-card reveal" href="#join" key={service.name}><span className="service-index">0{index + 1}</span><Icon className="service-icon" size={22} strokeWidth={1.3} /><div><h3>{service.name}</h3><p>{service.description}</p></div><ArrowUpRight className="service-arrow" size={17} /></a> })}</div></section>

      <section className="concept-section reveal"><p className="section-kicker">A simple question</p><h2>What if mosquitoes<br /><em>had everything we have?</em></h2><div className="concept-answer"><span className="answer-line" /><p>We built it.</p><span className="answer-line" /></div></section>

      <section className="snapshot-section"><div className="section-heading reveal"><p className="section-kicker">System snapshot</p><h2>Growing quietly.<br /><em>Everywhere at once.</em></h2></div><div className="stats-grid">{[['14.2M', 'KKU-IDs issued'], ['98.7%', 'Ecosystem satisfaction'], ['142', 'Active night zones'], ['24/7', 'Community support']].map(([number, label]) => <div className="stat reveal" key={label}><strong>{number}</strong><span>{label}</span></div>)}</div></section>

      <section className="join-section" id="join"><div className="join-glow" /><p className="section-kicker">Your place in the system</p><h2>Every mosquito<br /><em>deserves a place.</em></h2><a href="#top" className="kku-button">Create KKU-ID <ArrowUpRight size={16} /></a><p className="login-copy">Already registered? <a href="#top">Login to KKU <ArrowUpRight size={13} /></a></p><footer><span>© KKU / Kothuk Kudumba Unit</span><span>Built for the night shift</span><a href="#top">Back to top ↑</a></footer></section>
    </main>
  )
}

